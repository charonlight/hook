// 使用 Java.perform 函数确保 Frida 在 Java 虚拟机中运行此代码
Java.perform(function () {
  // 获取 "e.c.a.i.c" 类
  var c = Java.use("e.c.a.i.c");
  // 获取 "com.qq.lib.EncryptUtil" 类
  var EncryptUtil = Java.use("com.qq.lib.EncryptUtil");
  // 定义一个变量来存储从 Python 接收到的新字符串
  var newStr;

  // Hook "e.c.a.i.c" 类中的 "a" 方法，参数类型为 "java.lang.String"
  c.a.overload('java.lang.String').implementation = function (str) {
    // 将原始参数转换为 JSON 字符串并将其发送给 Python
    send({ type: 'REQ', data: JSON.stringify(str) });

    // 等待来自 Python 的新参数
    var newArgs = recv('NEW_REQ', function (data) {
      // 将从 Python 接收到的 JSON 字符串转换为 JavaScript 对象
      newStr = JSON.parse(data.payload);
    });
    // 等待 recv 函数处理完数据
    newArgs.wait();

    // 使用新参数调用原始方法并返回结果
    return this.a(newStr);
  }

  // 定义一个变量来存储从 Python 接收到的新明文
  var newPlaintext;

  // Hook "com.qq.lib.EncryptUtil" 类中的 "decrypt" 方法
  EncryptUtil.decrypt.implementation = function (str, str2) {
    // 使用原始参数调用原始解密方法并将结果存储在 "plaintext" 变量中
    var plaintext = this.decrypt(str, str2);

    // 将解密后的明文转换为 JSON 字符串并将其发送给 Python
    send({ type: 'RESP', data: JSON.stringify(plaintext) });

    // 等待来自 Python 的新明文
    var newResult = recv('NEW_RESP', function (data) {
      // 将从 Python 接收到的 JSON 字符串转换为 JavaScript 对象
      newPlaintext = JSON.parse(data.payload);
    });
    // 等待 recv 函数处理完数据
    newResult.wait();

    // 返回新的明文
    return newPlaintext;
  }
});
