import argparse
from threading import Thread
from http.server import HTTPServer, BaseHTTPRequestHandler
import sys
import requests
import frida

# 定义端口号
ECHO_PORT = 28080
BURP_PORT = 8080


# 创建一个请求处理器类，继承自 BaseHTTPRequestHandler
class RequestHandler(BaseHTTPRequestHandler):
    # 定义处理请求的方法
    def do_REQUEST(self):
        content_length = int(self.headers.get('content-length', 0))
        self.send_response(200)
        self.end_headers()
        self.wfile.write(self.rfile.read(content_length))

    # 处理响应的方法与处理请求的方法相同
    do_RESPONSE = do_REQUEST


def echo_server_thread():
    print('start echo server at port {}'.format(ECHO_PORT))
    server = HTTPServer(('', ECHO_PORT), RequestHandler)
    server.serve_forever()


t = Thread(target=echo_server_thread)
t.daemon = True
t.start()

# 添加命令行参数解析
parser = argparse.ArgumentParser(description="Frida Python script with command line arguments.")
parser.add_argument("process_name", help="The process name you want to attach to.")
parser.add_argument("js_file", help="The path to the Frida JS script.")
args = parser.parse_args()

# 通过 USB 设备附加到指定进程
session = frida.get_usb_device().attach(args.process_name)

# 加载 Frida JS 脚本
with open(args.js_file, "r", encoding='utf-8') as f:
    js_code = f.read()
script = session.create_script(js_code)


# 定义处理来自 Frida 脚本的消息的函数
def on_message(message, data):
    if message['type'] == 'send':
        payload = message['payload']
        _type, data = payload['type'], payload['data']
        # print(message)
        if _type == 'REQ':
            data = str(data)
            r = requests.request('REQUEST', 'http://127.0.0.1:{}/'.format(ECHO_PORT),
                                 proxies={'http': 'http://127.0.0.1:{}'.format(BURP_PORT)},
                                 data=data.encode('utf-8'))

            script.post({'type': 'NEW_REQ', 'payload': r.text})

        elif _type == 'RESP':
            r = requests.request('RESPONSE', 'http://127.0.0.1:{}/'.format(ECHO_PORT),
                                 proxies={'http': 'http://127.0.0.1:{}'.format(BURP_PORT)},
                                 data=data.encode('utf-8'))

            script.post({'type': 'NEW_RESP', 'payload': r.text})


# 为 Frida 脚本设置消息处理函数
script.on('message', on_message)
script.load()

# 使主线程保持运行，等待用户输入
sys.stdin.read()
